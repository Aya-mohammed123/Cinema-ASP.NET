﻿using System.ComponentModel.DataAnnotations;

namespace FinalItiCinemaProject.Models
{
    public class Actor
    {

        [Key]
        public int ActorId { get; set; }
        [Display(Name = "Profile Picture ")]
        [Required(ErrorMessage ="Profile picture is required")]
        public String? ProfilrPictureURL { get; set; }
        [Display(Name = "Full Name")]
        [Required(ErrorMessage = "Name is required")]
        [StringLength(50,MinimumLength = 3, ErrorMessage = "Name must be between 3 & 50 char")]
        public string FullName { get; set; }
        [Display(Name = "Bio")]
        [Required(ErrorMessage = "Biography is required")]
        public String Bio { get; set; }
        public List<Actor_Movie> Actor_Movies { get; set; }
        public Actor()
        {
                Actor_Movies=new List<Actor_Movie>();
        }
    }
}
