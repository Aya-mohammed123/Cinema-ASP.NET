﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using FinalItiCinemaProject.Data;

namespace FinalItiCinemaProject.Models
{
    public class Movie
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Full Name")]
        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be between 3 & 50 char")]
        public string Name { get; set; }
        
        [Required(ErrorMessage = "Description is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be between 3 & 50 char")]
        public string Description { get; set; }
        [Required(ErrorMessage = "price  is required")]
        public double Price { get; set; }
        [Required(ErrorMessage = "image is required")]
        public string ImageURL { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime StartDate { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime EndDate { get; set; }
        public MovieCategory MovieCategory { get; set; }
        //Relationship
        public List<Actor_Movie> Actor_Movies { get; set; }
        //cinema
        public int cinemaId { get; set; }
        [ForeignKey("cinemaId")]
        public Cinema cinema { get; set; }
        //Procedure
        public int procedureId { get; set; }
        [ForeignKey("procedureId")]
        public Procedure procedure { get; set; }
        public Movie()
        {
            Actor_Movies= new List<Actor_Movie>();
        }
    }
}
