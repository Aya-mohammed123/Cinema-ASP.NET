﻿namespace FinalItiCinemaProject.Data
{
    public enum MovieCategory
    {
        Action=1,
           comedy,
           Drama,
           Documentary,
            cartoon
    }
}
