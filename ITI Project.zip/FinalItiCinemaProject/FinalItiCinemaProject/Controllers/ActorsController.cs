﻿using FinalItiCinemaProject.Data;
using FinalItiCinemaProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Operations;

namespace FinalItiCinemaProject.Controllers
{
    public class ActorsController : Controller
    {
        private readonly AppDbContext _context;
        public ActorsController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> IndexAsync()
        {
            var data = _context.Actors.ToList();
            return View(data);
        }












        //Get & Post Method for add new data 







        public IActionResult Create()
        {
            return View();
        }
        //Post method
        [HttpPost]



         




        public IActionResult Create(Actor actor)
    {
            if (ModelState.IsValid)
            {
                _context.Add(actor);

                _context.SaveChanges();
                return RedirectToAction("Index");
            }
        
        return View();
    }



        //Get & Post Method for edit new data 




        public IActionResult Edit(int id)
        {

            var item= _context.Actors.Find(id);
            return View(item);
        }
        //Post method
        [HttpPost]
        public IActionResult Edit(Actor actor)
        {
            if (ModelState.IsValid)
            {
                _context.Update(actor);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View();
        }



        //Get & Post Method for delete new data 




        public IActionResult Delete(int id)
        {
            var item = _context.Actors.Find(id);
            _context.Remove(item);
            _context.SaveChanges();
            return RedirectToAction("Index");
            //we have no need to view page
        }
        
        
    }
}
