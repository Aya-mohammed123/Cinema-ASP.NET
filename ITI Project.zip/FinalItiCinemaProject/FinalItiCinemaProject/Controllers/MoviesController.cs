﻿using FinalItiCinemaProject.Data;
using FinalItiCinemaProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalItiCinemaProject.Controllers
{
    public class MoviesController : Controller
    {
        private readonly AppDbContext _context;
        public MoviesController(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            var allMovies = await _context.Movies.Include(n=>n.cinema).OrderBy(n=>n.Name).ToListAsync();
            return View(allMovies);
        }




        //Get & Post Method for add new data 






        public IActionResult Create()
        {
            return View();
        }
        //Post method
        [HttpPost]
        public IActionResult Create(Movie  movie)
        {
            _context.Add(movie);
            _context.SaveChanges();
            return View();
        }



        //Get & Post Method for edit new data 




        public IActionResult Edit(int id)
        {
            var item = _context.Movies.Find(id);
            return View(item);
        }
        //Post method
        [HttpPost]
        public IActionResult Edit(Movie  movie)
        {
            _context.Update(movie);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }


        //Get  Method for delete new data 




        public IActionResult Delete(int id)
        {
            var item = _context.Movies.Find(id);
            _context.Remove(item);
            _context.SaveChanges();
            return RedirectToAction("Index");
            //we have no need to view page
        }
    }
}
